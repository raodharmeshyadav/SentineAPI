"""
Generates SentinelAPI_Presentation.pptx
Clean, professional academic/engineering hackathon presentation.
Zero AI buzzwords. 100% authentic student engineering project.
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE
import os

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Clean Modern Dark Palette (GitHub/VSCode style)
COLOR_BG = RGBColor(11, 15, 25)        # #0b0f19
COLOR_CARD = RGBColor(17, 24, 39)      # #111827
COLOR_BLUE = RGBColor(2, 132, 199)     # #0284c7
COLOR_RED = RGBColor(239, 68, 68)      # #ef4444
COLOR_GREEN = RGBColor(16, 185, 129)   # #10b981
COLOR_WHITE = RGBColor(241, 245, 249)  # #f1f5f9
COLOR_MUTED = RGBColor(148, 163, 184)  # #94a3b8

blank_layout = prs.slide_layouts[6]

def set_bg(slide):
    bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = COLOR_BG
    bg.line.fill.background()

# ==================== SLIDE 1: TITLE ====================
s1 = prs.slides.add_slide(blank_layout)
set_bg(s1)

tb1 = s1.shapes.add_textbox(Inches(1.5), Inches(2.0), Inches(10.33), Inches(3.5))
tf1 = tb1.text_frame
tf1.word_wrap = True

p_tag = tf1.paragraphs[0]
p_tag.text = "AMI HACKS 1.0  |  TRACK C: API SECURITY & DEVELOPER TOOLING"
p_tag.font.size = Pt(13)
p_tag.font.bold = True
p_tag.font.color.rgb = COLOR_BLUE

p_title = tf1.add_paragraph()
p_title.text = "SentinelAPI"
p_title.font.size = Pt(54)
p_title.font.bold = True
p_title.font.color.rgb = COLOR_WHITE

p_sub = tf1.add_paragraph()
p_sub.text = "Automated OpenAPI Vulnerability & Authorization Test Suite"
p_sub.font.size = Pt(22)
p_sub.font.color.rgb = COLOR_MUTED

# ==================== SLIDE 2: PROBLEM ====================
s2 = prs.slides.add_slide(blank_layout)
set_bg(s2)

tb2 = s2.shapes.add_textbox(Inches(1.0), Inches(0.8), Inches(11.33), Inches(1.2))
tf2 = tb2.text_frame
p2_lbl = tf2.paragraphs[0]
p2_lbl.text = "01. PROBLEM STATEMENT"
p2_lbl.font.size = Pt(12)
p2_lbl.font.bold = True
p2_lbl.font.color.rgb = COLOR_RED

p2_h = tf2.add_paragraph()
p2_h.text = "Why API Authorization Flaws Go Undetected"
p2_h.font.size = Pt(30)
p2_h.font.bold = True
p2_h.font.color.rgb = COLOR_WHITE

card_data = [
    ("Missing Object-Level Checks (BOLA)", "When building backend APIs in FastAPI or Express, developers often verify that a token is valid, but forget to verify whether that user owns the specific ID in the URL. A user can simply change /orders/101 to /orders/102 and read someone else's data.", COLOR_RED),
    ("Traditional Scanners Miss Logic", "Standard scanners (like OWASP ZAP) test for syntax flaws (SQL Injection, XSS, bad headers). Because an IDOR request is syntactically valid (HTTP 200 OK), generic scanners assume it succeeded and miss the data breach completely.", COLOR_BLUE),
    ("Excessive Data in Responses", "APIs frequently return full database rows rather than filtered DTOs. Sensitive columns like password hashes, SSNs, or internal keys leak into JSON responses without anyone noticing.", COLOR_GREEN)
]

for idx, (title, desc, color) in enumerate(card_data):
    left = Inches(1.0 + idx * 3.9)
    card = s2.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, Inches(2.2), Inches(3.6), Inches(4.3))
    card.fill.solid()
    card.fill.fore_color.rgb = COLOR_CARD
    card.line.color.rgb = color
    card.line.width = Pt(1.5)
    
    ctf = card.text_frame
    ctf.word_wrap = True
    cp1 = ctf.paragraphs[0]
    cp1.text = title
    cp1.font.size = Pt(16)
    cp1.font.bold = True
    cp1.font.color.rgb = COLOR_WHITE
    
    cp2 = ctf.add_paragraph()
    cp2.text = f"\n{desc}"
    cp2.font.size = Pt(12)
    cp2.font.color.rgb = COLOR_MUTED

# ==================== SLIDE 3: HOW IT WORKS ====================
s3 = prs.slides.add_slide(blank_layout)
set_bg(s3)

tb3 = s3.shapes.add_textbox(Inches(1.0), Inches(0.8), Inches(11.33), Inches(1.2))
tf3 = tb3.text_frame
p3_lbl = tf3.paragraphs[0]
p3_lbl.text = "02. SYSTEM DESIGN"
p3_lbl.font.size = Pt(12)
p3_lbl.font.bold = True
p3_lbl.font.color.rgb = COLOR_BLUE

p3_h = tf3.add_paragraph()
p3_h.text = "How SentinelAPI Audits APIs Automatically"
p3_h.font.size = Pt(30)
p3_h.font.bold = True
p3_h.font.color.rgb = COLOR_WHITE

steps = [
    ("Step 1: Spec Parsing", "Parses the OpenAPI 3.0 / Swagger JSON specification to map all endpoints, path parameters, and request schemas."),
    ("Step 2: Dual-Token Credential Swapping", "Our core testing technique: We issue requests using User A's token against User B's resource IDs. If User B's private data is returned with 200 OK, BOLA/IDOR is deterministically confirmed."),
    ("Step 3: Response Field Inspection", "Scans JSON response bodies using field matching and regular expressions to detect leaked password hashes ($2b$), SSNs, and private tokens."),
    ("Step 4: Developer Code Fixes", "For every finding, SentinelAPI generates a ready-to-use cURL reproduction command and a concrete Python/FastAPI code patch.")
]

for idx, (title, desc) in enumerate(steps):
    top = Inches(2.2 + idx * 1.15)
    card = s3.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), top, Inches(11.33), Inches(0.95))
    card.fill.solid()
    card.fill.fore_color.rgb = COLOR_CARD
    card.line.color.rgb = COLOR_BLUE if idx == 1 else COLOR_CARD
    card.line.width = Pt(1.5)
    
    ctf = card.text_frame
    ctf.word_wrap = True
    cp1 = ctf.paragraphs[0]
    cp1.text = title
    cp1.font.size = Pt(15)
    cp1.font.bold = True
    cp1.font.color.rgb = COLOR_BLUE if idx == 1 else COLOR_WHITE
    
    cp2 = ctf.add_paragraph()
    cp2.text = desc
    cp2.font.size = Pt(12)
    cp2.font.color.rgb = COLOR_MUTED

# ==================== SLIDE 4: RESULTS ====================
s4 = prs.slides.add_slide(blank_layout)
set_bg(s4)

tb4 = s4.shapes.add_textbox(Inches(1.0), Inches(0.8), Inches(11.33), Inches(1.2))
tf4 = tb4.text_frame
p4_lbl = tf4.paragraphs[0]
p4_lbl.text = "03. EXPERIMENTAL RESULTS"
p4_lbl.font.size = Pt(12)
p4_lbl.font.bold = True
p4_lbl.font.color.rgb = COLOR_GREEN

p4_h = tf4.add_paragraph()
p4_h.text = "Audit Results on Sample Clinic API (Apex Health)"
p4_h.font.size = Pt(30)
p4_h.font.bold = True
p4_h.font.color.rgb = COLOR_WHITE

findings = [
    ("CRITICAL (CVSS 9.4)", "GET /api/v1/patients/{patient_id}/records", "User A token accessed User B's patient record (ID 102) and leaked medical diagnosis & prescriptions.", COLOR_RED),
    ("CRITICAL (CVSS 9.1)", "DELETE /api/v1/admin/users/{user_id}", "Admin delete endpoint executed by a regular non-admin user token without 403 Forbidden.", COLOR_RED),
    ("HIGH (CVSS 8.2)", "GET /api/v1/users/{user_id}/profile", "Public user profile endpoint leaked raw database columns: password_hash, ssn, and auth secrets.", COLOR_BLUE),
    ("MEDIUM (CVSS 5.9)", "POST /api/v1/auth/login", "Endpoint accepted 15 rapid consecutive login requests with zero rate-limiting or 429 response.", COLOR_GREEN)
]

for idx, (badge, route, desc, color) in enumerate(findings):
    r = idx // 2
    c = idx % 2
    left = Inches(1.0 + c * 5.8)
    top = Inches(2.2 + r * 2.2)
    
    card = s4.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, Inches(5.5), Inches(1.9))
    card.fill.solid()
    card.fill.fore_color.rgb = COLOR_CARD
    card.line.color.rgb = color
    card.line.width = Pt(1)
    
    ctf = card.text_frame
    ctf.word_wrap = True
    cp1 = ctf.paragraphs[0]
    cp1.text = badge
    cp1.font.size = Pt(12)
    cp1.font.bold = True
    cp1.font.color.rgb = color
    
    cp2 = ctf.add_paragraph()
    cp2.text = route
    cp2.font.size = Pt(14)
    cp2.font.bold = True
    cp2.font.color.rgb = COLOR_WHITE
    
    cp3 = ctf.add_paragraph()
    cp3.text = desc
    cp3.font.size = Pt(11)
    cp3.font.color.rgb = COLOR_MUTED

# ==================== SLIDE 5: BEFORE & AFTER FIX ====================
s5 = prs.slides.add_slide(blank_layout)
set_bg(s5)

tb5 = s5.shapes.add_textbox(Inches(1.0), Inches(0.8), Inches(11.33), Inches(1.2))
tf5 = tb5.text_frame
p5_lbl = tf5.paragraphs[0]
p5_lbl.text = "04. VERIFYING THE FIX"
p5_lbl.font.size = Pt(12)
p5_lbl.font.bold = True
p5_lbl.font.color.rgb = COLOR_BLUE

p5_h = tf5.add_paragraph()
p5_h.text = "Before vs After Applying Code Fixes"
p5_h.font.size = Pt(30)
p5_h.font.bold = True
p5_h.font.color.rgb = COLOR_WHITE

# Before Card
c_before = s5.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(1.0), Inches(2.3), Inches(5.5), Inches(4.2))
c_before.fill.solid()
c_before.fill.fore_color.rgb = COLOR_CARD
c_before.line.color.rgb = COLOR_RED
c_before.line.width = Pt(1.5)
tf_b = c_before.text_frame
tf_b.word_wrap = True
tf_b.paragraphs[0].text = "BEFORE (Vulnerable API)"
tf_b.paragraphs[0].font.size = Pt(18)
tf_b.paragraphs[0].font.bold = True
tf_b.paragraphs[0].font.color.rgb = COLOR_RED

p_b_desc = tf_b.add_paragraph()
p_b_desc.text = "\n• Score: 5 / 100 (Grade F)\n• 10 Vulnerabilities detected\n• BOLA allows full cross-patient data access\n• Public profiles leak SSNs and hashes\n• Admin endpoints open to regular users"
p_b_desc.font.size = Pt(14)
p_b_desc.font.color.rgb = COLOR_MUTED

# After Card
c_after = s5.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.8), Inches(2.3), Inches(5.5), Inches(4.2))
c_after.fill.solid()
c_after.fill.fore_color.rgb = COLOR_CARD
c_after.line.color.rgb = COLOR_GREEN
c_after.line.width = Pt(1.5)
tf_a = c_after.text_frame
tf_a.word_wrap = True
tf_a.paragraphs[0].text = "AFTER (Patched API)"
tf_a.paragraphs[0].font.size = Pt(18)
tf_a.paragraphs[0].font.bold = True
tf_a.paragraphs[0].font.color.rgb = COLOR_GREEN

p_a_desc = tf_a.add_paragraph()
p_a_desc.text = "\n• Score: 100 / 100 (Grade A)\n• 0 Vulnerabilities\n• Object-level ownership check enforced (403)\n• Pydantic response DTO filters internal fields\n• Admin routes protected by RBAC dependency"
p_a_desc.font.size = Pt(14)
p_a_desc.font.color.rgb = COLOR_MUTED

# ==================== SLIDE 6: CONCLUSION ====================
s6 = prs.slides.add_slide(blank_layout)
set_bg(s6)

tb6 = s6.shapes.add_textbox(Inches(1.5), Inches(2.2), Inches(10.33), Inches(3.5))
tf6 = tb6.text_frame
tf6.word_wrap = True

p6_tag = tf6.paragraphs[0]
p6_tag.text = "AMI HACKS 1.0  |  TRACK C CONCLUSION"
p6_tag.font.size = Pt(13)
p6_tag.font.bold = True
p6_tag.font.color.rgb = COLOR_GREEN

p6_title = tf6.add_paragraph()
p6_title.text = "Automated Security for Every API."
p6_title.font.size = Pt(46)
p6_title.font.bold = True
p6_title.font.color.rgb = COLOR_WHITE

p6_sub = tf6.add_paragraph()
p6_sub.text = '\nSentinelAPI helps developers catch authorization flaws before deployment.\nThank you! We are open for questions.'
p6_sub.font.size = Pt(17)
p6_sub.font.color.rgb = COLOR_MUTED

output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "SentinelAPI_Presentation.pptx")
prs.save(output_path)
print(f"[+] Clean student presentation generated at: {output_path}")
