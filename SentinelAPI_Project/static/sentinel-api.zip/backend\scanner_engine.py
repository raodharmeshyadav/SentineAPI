"""
SentinelAPI - OpenAPI Security Scanner & Audit Tool
Built for AmiHacks 1.0 (Track C: API Security)

This module parses OpenAPI 3.0 / Swagger specifications and performs
automated security checks:
1. Object-Level Authorization (IDOR / BOLA) via dual-token credential testing
2. Function-Level Authorization (Privilege Escalation) on admin endpoints
3. Sensitive data exposure in JSON responses (PII, tokens, hashes)
4. Missing HTTP security headers (HSTS, CSP, X-Frame-Options)
5. Missing rate-limiting on sensitive endpoints
"""

import re
import json
import time
import requests
from typing import Dict, List, Any, Optional

# Regex patterns for detecting unintentional data exposure in API responses
SENSITIVE_FIELD_NAMES = [
    "password", "password_hash", "passwd", "hash", "secret",
    "ssn", "social_security", "auth_secret", "api_key",
    "private_key", "backup_code", "salary", "credit_card"
]

REGEX_DETECTORS = [
    (re.compile(r"\$2[aby]\$\d{2}\$[./0-9A-Za-z]{53}"), "Bcrypt password hash leaked"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "Social Security Number (SSN) leaked"),
    (re.compile(r"sk_live_[a-zA-Z0-9_]{16,}"), "Live API secret key leaked"),
    (re.compile(r"postgres(?:ql)?:\/\/[^:]+:[^@]+@[^\/]+\/\w+"), "Database connection URI with credentials leaked"),
    (re.compile(r"redis:\/\/:[^@]+@[\w\.-]+:\d+"), "Redis connection string with password leaked")
]


class APISecurityAuditor:
    def __init__(self, target_base_url: str, openapi_spec: Dict[str, Any], test_auth: Optional[Dict[str, Any]] = None):
        self.base_url = target_base_url.rstrip("/")
        self.spec = openapi_spec
        self.paths = openapi_spec.get("paths", {})
        
        # Test accounts used for cross-account authorization verification
        self.auth = test_auth or {
            "user_a": {
                "token": "tok_alice_9981a",
                "header": "Bearer tok_alice_9981a",
                "user_id": "101",
                "label": "User A (Alice)"
            },
            "user_b": {
                "token": "tok_bob_3342b",
                "header": "Bearer tok_bob_3342b",
                "user_id": "102",
                "known_resource_ids": {"patient_id": "102", "order_id": "5002", "user_id": "102"},
                "label": "User B (Bob - Victim)"
            }
        }
        
        self.findings: List[Dict[str, Any]] = []
        self.logs: List[str] = []
        self.endpoints_tested = 0

    def add_log(self, text: str):
        t = time.strftime("%H:%M:%S")
        self.logs.append(f"[{t}] {text}")

    def run_audit(self) -> Dict[str, Any]:
        start = time.time()
        self.add_log(f"Starting API security audit on: {self.base_url}")
        self.add_log(f"Loaded OpenAPI spec: {self.spec.get('info', {}).get('title', 'API')} (v{self.spec.get('info', {}).get('version', '1.0')})")
        self.add_log(f"Found {len(self.paths)} endpoints to test.")

        # Check 1: Security Headers & CORS
        self.check_gateway_headers()

        # Check 2: Iterate each route in the spec
        for route_path, path_data in self.paths.items():
            for http_method, operation in path_data.items():
                method = http_method.upper()
                if method not in ["GET", "POST", "PUT", "DELETE"]:
                    continue

                self.endpoints_tested += 1
                self.add_log(f"Testing [{method}] {route_path}")

                # Test for IDOR / BOLA if route takes an ID parameter
                if any(param in route_path for param in ["{id}", "{patient_id}", "{order_id}", "{user_id}"]):
                    self.test_idor_bola(route_path, method, operation)

                # Test for Sensitive Data Exposure on GET/POST
                if method in ["GET", "POST"]:
                    self.test_data_exposure(route_path, method, operation)

                # Test for Broken Function Level Authorization on admin routes
                if "admin" in route_path.lower() or method == "DELETE":
                    self.test_admin_privilege_escalation(route_path, method, operation)

                # Test for Rate Limiting on auth/export endpoints
                if any(k in route_path.lower() for k in ["login", "auth", "export"]):
                    self.test_rate_limits(route_path, method, operation)

        duration = round(time.time() - start, 2)
        self.add_log(f"Audit completed in {duration}s. Identified {len(self.findings)} issues.")

        summary = self.calculate_summary(duration)
        return {
            "summary": summary,
            "findings": self.findings,
            "logs": self.logs,
            "spec_title": self.spec.get("info", {}).get("title", "Target API"),
            "target_url": self.base_url,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }

    def check_gateway_headers(self):
        """Validates standard defensive HTTP response headers."""
        try:
            res = requests.get(f"{self.base_url}/api/v1/health", timeout=3)
            headers = res.headers
            missing = []

            required_headers = [
                ("Strict-Transport-Security", "Enforces HTTPS connections."),
                ("X-Content-Type-Options", "Prevents MIME-sniffing."),
                ("X-Frame-Options", "Prevents UI clickjacking."),
                ("Content-Security-Policy", "Restricts unauthorized script execution.")
            ]

            for h, why in required_headers:
                if h not in headers:
                    missing.append(f"{h}: {why}")

            if missing:
                self.findings.append({
                    "id": f"SEC-HDR-{len(self.findings) + 1}",
                    "title": "Missing HTTP Security Headers",
                    "category": "OWASP API8: Security Misconfiguration",
                    "severity": "MEDIUM",
                    "cvss_score": 5.3,
                    "endpoint": "/api/v1/health",
                    "method": "GET",
                    "description": "The API server responses omit essential defensive HTTP headers that protect web clients against clickjacking and MIME-type sniffing.",
                    "evidence": {"missing_headers": missing},
                    "reproduction_curl": f"curl -I {self.base_url}/api/v1/health",
                    "fix_code": """# Middleware fix in FastAPI
@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response"""
                })

            # Check CORS
            if headers.get("Access-Control-Allow-Origin") == "*":
                self.findings.append({
                    "id": f"SEC-CORS-{len(self.findings) + 1}",
                    "title": "Overly Permissive CORS Origin (*)",
                    "category": "OWASP API8: Security Misconfiguration",
                    "severity": "MEDIUM",
                    "cvss_score": 6.5,
                    "endpoint": "/api/v1/health",
                    "method": "GET",
                    "description": "Access-Control-Allow-Origin header is set to wildcard '*', which allows arbitrary third-party web domains to read sensitive API responses.",
                    "evidence": {"observed_cors": headers.get("Access-Control-Allow-Origin")},
                    "reproduction_curl": f"curl -H 'Origin: https://attacker.com' -I {self.base_url}/api/v1/health",
                    "fix_code": """# CORS Fix: Restrict to explicit trusted domains
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend-app.com"],
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Authorization", "Content-Type"],
)"""
                })
        except Exception as e:
            self.add_log(f"Warning: Could not connect for headers test: {e}")

    def test_idor_bola(self, route_template: str, method: str, operation: Dict[str, Any]):
        """
        Cross-account authorization test:
        Sends User A's authorization token with User B's resource ID in path.
        """
        # Substitute with User B's ID
        test_path = route_template
        for key in ["{patient_id}", "{order_id}", "{user_id}", "{id}"]:
            if key in test_path:
                param_name = key.strip("{}")
                test_val = self.auth["user_b"]["known_resource_ids"].get(param_name, "102")
                test_path = test_path.replace(key, test_val)

        target_url = f"{self.base_url}{test_path}"
        user_a_token = self.auth["user_a"]["header"]

        try:
            res = requests.request(method, target_url, headers={"Authorization": user_a_token}, timeout=3)
            if res.status_code == 200:
                body_text = res.text
                # Check if User B's private data was returned
                if "Bob Miller" in body_text or "102" in body_text or "5002" in body_text:
                    self.add_log(f"[CRITICAL] BOLA verified on {method} {route_template}!")
                    self.findings.append({
                        "id": f"IDOR-{len(self.findings) + 1}",
                        "title": f"Broken Object-Level Authorization (BOLA/IDOR) on {route_template}",
                        "category": "OWASP API1: Broken Object Level Authorization",
                        "severity": "CRITICAL",
                        "cvss_score": 9.4,
                        "endpoint": route_template,
                        "method": method,
                        "description": (
                            f"User A ({self.auth['user_a']['label']}) was able to access the private records "
                            f"of User B ({self.auth['user_b']['label']}) simply by changing the ID in the request URL. "
                            f"The backend verified that the token was valid, but failed to verify object ownership."
                        ),
                        "evidence": {
                            "request_url": target_url,
                            "authenticated_as": self.auth["user_a"]["label"],
                            "victim_data_returned": res.json() if res.headers.get("content-type", "").startswith("application/json") else res.text[:200]
                        },
                        "reproduction_curl": f"curl -X {method} '{target_url}' \\\n  -H 'Authorization: {user_a_token}'",
                        "fix_code": """# Fix: Enforce ownership check before fetching data
@app.get("/api/v1/patients/{patient_id}/records")
def get_patient_records(patient_id: str, current_user = Depends(get_current_user)):
    # Verify current user owns this record or is an authorized doctor/admin
    if current_user.role != "admin" and current_user.patient_id != patient_id:
        raise HTTPException(status_code=403, detail="Forbidden: You do not have permission to view this record.")
    return db.fetch_patient_records(patient_id)"""
                    })
        except Exception as e:
            self.add_log(f"Error testing IDOR on {route_template}: {e}")

    def test_data_exposure(self, route_template: str, method: str, operation: Dict[str, Any]):
        """Inspects response payloads for unneeded sensitive database columns."""
        test_path = route_template.replace("{user_id}", "101").replace("{id}", "101")
        if "{" in test_path:
            return

        target_url = f"{self.base_url}{test_path}"
        try:
            res = requests.request(method, target_url, headers={"Authorization": self.auth["user_a"]["header"]}, timeout=3)
            if res.status_code == 200 and "application/json" in res.headers.get("content-type", ""):
                data = res.json()
                data_str = json.dumps(data)
                leaks = []

                # Key name checks
                if isinstance(data, dict):
                    for k, v in data.items():
                        if any(s in k.lower() for s in SENSITIVE_FIELD_NAMES):
                            leaks.append(f"Field '{k}' exposed with value: '{str(v)[:30]}'")

                # Regex pattern checks
                for pattern, label in REGEX_DETECTORS:
                    if pattern.search(data_str):
                        leaks.append(label)

                if leaks:
                    self.add_log(f"[HIGH] Excessive data exposure on {method} {route_template}")
                    self.findings.append({
                        "id": f"DATA-EXP-{len(self.findings) + 1}",
                        "title": f"Excessive Data Exposure on {route_template}",
                        "category": "OWASP API3: Broken Object Property Level Authorization",
                        "severity": "HIGH",
                        "cvss_score": 8.2,
                        "endpoint": route_template,
                        "method": method,
                        "description": (
                            "The endpoint returns internal database attributes (such as password hashes, SSNs, or internal keys) "
                            "in the JSON response. Clients receive fields they never requested and should never see."
                        ),
                        "evidence": {"exposed_fields": leaks, "sample_payload": data},
                        "reproduction_curl": f"curl -X {method} '{target_url}' \\\n  -H 'Authorization: {self.auth['user_a']['header']}'",
                        "fix_code": """# Fix: Use an explicit Pydantic response_model (DTO) to filter out internal columns
class UserProfileResponse(BaseModel):
    id: str
    username: str
    email: EmailStr
    full_name: str
    # password_hash, ssn, and internal secrets are excluded from this schema

@app.get("/api/v1/users/{user_id}/profile", response_model=UserProfileResponse)
def get_user_profile(user_id: str, current_user = Depends(get_current_user)):
    return db.get_user(user_id)"""
                    })
        except Exception as e:
            self.add_log(f"Error testing data exposure on {route_template}: {e}")

    def test_admin_privilege_escalation(self, route_template: str, method: str, operation: Dict[str, Any]):
        """Verifies if unprivileged user tokens can execute administrative actions."""
        test_path = route_template.replace("{user_id}", "102").replace("{id}", "102")
        target_url = f"{self.base_url}{test_path}"

        try:
            # Send standard user token (Alice) to an admin route
            res = requests.request(method, target_url, headers={"Authorization": self.auth["user_a"]["header"]}, timeout=3)
            if res.status_code in [200, 204]:
                self.add_log(f"[CRITICAL] Privilege escalation on {method} {route_template}")
                self.findings.append({
                    "id": f"BFLA-{len(self.findings) + 1}",
                    "title": f"Broken Function Level Authorization (Privilege Escalation) on {route_template}",
                    "category": "OWASP API5: Broken Function Level Authorization",
                    "severity": "CRITICAL",
                    "cvss_score": 9.1,
                    "endpoint": route_template,
                    "method": method,
                    "description": (
                        f"An administrative endpoint was successfully executed by a regular, non-admin user "
                        f"({self.auth['user_a']['label']}). The backend lacks role-based access control (RBAC) checks."
                    ),
                    "evidence": {
                        "tested_url": target_url,
                        "used_role": "user",
                        "response_status": res.status_code,
                        "response_body": res.text[:150]
                    },
                    "reproduction_curl": f"curl -X {method} '{target_url}' \\\n  -H 'Authorization: {self.auth['user_a']['header']}'",
                    "fix_code": """# Fix: Require admin role dependency
def require_admin(current_user = Depends(get_current_user)):
    if current_user.role != "admin":
        raise HTTPException(status_code=403, detail="Forbidden: Admin access required.")
    return current_user

@app.delete("/api/v1/admin/users/{user_id}", dependencies=[Depends(require_admin)])
def delete_user(user_id: str):
    return db.delete_user(user_id)"""
                })
        except Exception as e:
            self.add_log(f"Error testing privilege escalation on {route_template}: {e}")

    def test_rate_limits(self, route_template: str, method: str, operation: Dict[str, Any]):
        """Checks for missing request throttling on sensitive endpoints."""
        target_url = f"{self.base_url}{route_template}"
        burst_count = 15
        successes = 0

        try:
            for _ in range(burst_count):
                if method == "POST":
                    r = requests.post(target_url, json={"username": "test", "password": "wrong"}, timeout=2)
                else:
                    r = requests.get(target_url, headers={"Authorization": self.auth["user_a"]["header"]}, timeout=2)
                
                if r.status_code == 429:
                    return  # Properly throttled!
                if r.status_code in [200, 401]:
                    successes += 1

            if successes == burst_count:
                self.findings.append({
                    "id": f"RATE-LIMIT-{len(self.findings) + 1}",
                    "title": f"Missing Rate Limiting on {route_template}",
                    "category": "OWASP API4: Unrestricted Resource Consumption",
                    "severity": "MEDIUM",
                    "cvss_score": 5.9,
                    "endpoint": route_template,
                    "method": method,
                    "description": (
                        f"The endpoint accepted {burst_count} rapid requests without returning HTTP 429 (Too Many Requests). "
                        "This leaves the route vulnerable to credential brute-forcing and denial-of-service."
                    ),
                    "evidence": {"requests_sent": burst_count, "all_accepted": True},
                    "reproduction_curl": f"for i in {{1..{burst_count}}}; do curl -s -o /dev/null -w '%{{http_code}}\\n' {target_url}; done",
                    "fix_code": """# Fix: Add rate limiter middleware (e.g. slowapi)
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/api/v1/auth/login")
@limiter.limit("5/minute")
def login(request: Request, creds: LoginRequest):
    return authenticate(creds)"""
                })
        except Exception:
            pass

    def calculate_summary(self, duration: float) -> Dict[str, Any]:
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in self.findings:
            sev = f.get("severity", "LOW")
            counts[sev] = counts.get(sev, 0) + 1

        # Penalty score out of 100
        penalty = (counts["CRITICAL"] * 25) + (counts["HIGH"] * 15) + (counts["MEDIUM"] * 8) + (counts["LOW"] * 3)
        score = max(5, 100 - penalty)
        grade = "A" if score >= 85 else ("B" if score >= 75 else ("C" if score >= 60 else "F"))

        return {
            "score": score,
            "grade": grade,
            "counts": counts,
            "total_findings": len(self.findings),
            "endpoints_tested": self.endpoints_tested,
            "duration": duration
        }
