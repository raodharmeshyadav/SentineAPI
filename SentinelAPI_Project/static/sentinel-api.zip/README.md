# SentinelAPI - Automated OpenAPI Security Test Suite

An automated API vulnerability testing tool built for **AmiHacks 1.0 (Track C: API Security)**.

It parses standard OpenAPI 3.0 / Swagger JSON specifications and automatically tests for authorization flaws (BOLA / IDOR), excessive data exposure (PII / hashes), and privilege escalation before code is deployed.

---

## 🛠️ Tech Stack
- **Backend & Core Engine:** Python 3, FastAPI, Uvicorn, Requests, PyYAML
- **Frontend Test Suite:** HTML5, Vanilla JavaScript, Tailwind CSS
- **Presentation Deck:** Python-PPTX, Tailwind HTML Slides

---

## 🚀 How to Run

### 1. Install Dependencies
```bash
pip install fastapi uvicorn requests pyyaml python-pptx jinja2
```

### 2. Start Everything (Single Command)
```bash
python run.py
```
This single command automatically starts:
1. **Target Test API (Apex Health):** `http://127.0.0.1:8001` (with Swagger docs at `/docs`)
2. **SentinelAPI Test Dashboard:** `http://127.0.0.1:8000`
3. Opens the browser automatically.

---

## 🔍 How It Works

1. **Spec Ingestion**: Reads the target's OpenAPI 3.0 JSON specification (`/openapi.json`) and extracts all routes, path variables (`{id}`, `{patient_id}`), and query parameters.
2. **Dual-Token Authorization Testing**: 
   - Uses two valid test personas: User A (Alice) and User B (Bob).
   - Sends User A's Authorization token to fetch User B's private resource IDs.
   - If User B's private data returns with HTTP 200 OK, BOLA/IDOR is deterministically confirmed.
3. **Response Body Inspection**: 
   - Inspects JSON response keys and regex patterns to catch leaked password hashes (`$2b$`), SSNs, and live API secrets.
4. **Remediation Code Generation**:
   - Generates copyable cURL commands to reproduce each vulnerability.
   - Provides concrete Python/FastAPI code patches enforcing object-level authorization checks.

---

## 📁 Project Structure

```text
sentinel-api/
├── backend/
│   ├── scanner_engine.py      # Core OpenAPI parser & testing logic
│   └── server.py              # Management server & REST API
├── target_api/
│   ├── app.py                 # Intentionally vulnerable test API
│   └── app_secure.py          # Remediated & patched test API
├── static/
│   ├── index.html             # Developer test suite web UI
│   └── slides.html            # Web-based presentation slides
├── reports/                   # Saved scan JSON results
├── run.py                     # Single-command launcher
├── generate_pptx.py           # Presentation deck generator
├── SentinelAPI_Presentation.pptx # Pre-built presentation file
├── SPEAKER_CHEAT_SHEET.md     # Quick reference script for the speaker
└── README.md
```
