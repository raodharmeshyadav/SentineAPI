"""
SentinelAPI - Terminal CLI Tool
Allows running security audits directly from the command line.
Usage: python cli.py http://127.0.0.1:8001
"""

import sys
import time
import requests
import json

# ANSI Color codes for clean terminal output
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
BLUE = "\033[94m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"

def print_banner():
    print(f"\n{CYAN}{BOLD}================================================================={RESET}")
    print(f"{CYAN}{BOLD}           SENTINEL-API : OPENAPI SECURITY TEST SUITE             {RESET}")
    print(f"{CYAN}{BOLD}                  AMI HACKS 1.0 (TRACK C)                        {RESET}")
    print(f"{CYAN}{BOLD}================================================================={RESET}\n")

def main():
    target_url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8001"
    print_banner()
    print(f"[*] Target Base URL: {BOLD}{target_url}{RESET}")
    print(f"[*] Fetching OpenAPI Specification from {target_url}/openapi.json ...")
    
    try:
        r = requests.get(f"{target_url}/openapi.json", timeout=3)
        if r.status_code != 200:
            print(f"{RED}[-] Failed to load openapi.json (HTTP {r.status_code}){RESET}")
            return
        spec = r.json()
    except Exception as e:
        print(f"{RED}[-] Error connecting to target API: {e}{RESET}")
        return

    title = spec.get("info", {}).get("title", "Target API")
    version = spec.get("info", {}).get("version", "1.0.0")
    print(f"{GREEN}[+] Loaded Spec: {title} (v{version}){RESET}")
    print(f"[*] Dispatching Dual-Token Authorization Matrix...\n")

    # Send scan request to local engine
    try:
        scan_res = requests.post("http://127.0.0.1:8000/api/scan", json={"target_url": target_url}, timeout=10)
        data = scan_res.json()
    except Exception as e:
        print(f"{RED}[-] Scanner engine error: {e}{RESET}")
        return

    summary = data["summary"]
    findings = data["findings"]

    print(f"{BOLD}--- AUDIT RESULTS ---{RESET}")
    print(f"Endpoints Scanned: {summary['endpoints_tested']} in {summary['duration']}s")
    print(f"Overall Score:     {RED if summary['score'] < 50 else GREEN}{BOLD}{summary['score']} / 100 (Grade {summary['grade']}){RESET}")
    print(f"Total Issues:      {BOLD}{len(findings)}{RESET} (Critical: {summary['counts'].get('CRITICAL',0)}, High: {summary['counts'].get('HIGH',0)}, Medium: {summary['counts'].get('MEDIUM',0)})\n")

    print(f"{BOLD}{'SEVERITY':<12} {'METHOD':<8} {'ENDPOINT':<38} {'FINDING'}{RESET}")
    print("-" * 80)
    for f in findings:
        sev = f['severity']
        color = RED if sev == "CRITICAL" else (YELLOW if sev == "HIGH" else BLUE)
        print(f"{color}{BOLD}{sev:<12}{RESET} {f['method']:<8} {f['endpoint']:<38} {f['title'][:40]}")

    print("\n" + "=" * 80)
    print(f"{GREEN}[+] Full Web Dashboard: http://127.0.0.1:8000{RESET}")
    print(f"{GREEN}[+] Printable Report:   http://127.0.0.1:8000/report{RESET}")
    print("=" * 80 + "\n")

if __name__ == "__main__":
    main()
