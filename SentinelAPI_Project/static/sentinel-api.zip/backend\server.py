"""
SentinelAPI - Web Server & Audit API
Built for AmiHacks 1.0 (Track C)
"""

from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import requests
import json
import time
import os
import yaml

from backend.scanner_engine import APISecurityAuditor

app = FastAPI(
    title="SentinelAPI Scanner",
    description="Automated OpenAPI Security Audit Tool",
    version="1.0"
)

# Store scan results in memory
SCAN_RUNS: List[Dict[str, Any]] = []

class ScanRequest(BaseModel):
    target_url: str = "http://127.0.0.1:8001"
    spec_url: Optional[str] = "http://127.0.0.1:8001/openapi.json"
    spec_raw: Optional[str] = None

@app.get("/api/target/status")
def check_target():
    """Checks if the mock target API is currently online."""
    try:
        r = requests.get("http://127.0.0.1:8001/api/v1/health", timeout=1.5)
        if r.status_code == 200:
            return {"status": "online", "port": 8001, "api_name": "Apex Clinic API"}
    except Exception:
        pass
    return {"status": "offline", "port": 8001}

@app.post("/api/scan")
def trigger_audit(req: ScanRequest):
    """Executes the security scan against the given OpenAPI endpoint."""
    target_url = req.target_url.rstrip("/")
    spec_data = {}

    if req.spec_raw:
        try:
            spec_data = json.loads(req.spec_raw)
        except Exception:
            spec_data = yaml.safe_load(req.spec_raw)
    elif req.spec_url:
        try:
            r = requests.get(req.spec_url, timeout=5)
            spec_data = r.json()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Could not load spec from {req.spec_url}: {e}")
    else:
        try:
            r = requests.get(f"{target_url}/openapi.json", timeout=5)
            spec_data = r.json()
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Could not find openapi.json at {target_url}: {e}")

    # Run the auditor
    auditor = APISecurityAuditor(target_base_url=target_url, openapi_spec=spec_data)
    results = auditor.run_audit()
    results["id"] = f"AUDIT-{int(time.time())}"

    SCAN_RUNS.insert(0, results)
    return results

@app.get("/api/scans/latest")
def get_latest_scan():
    if not SCAN_RUNS:
        return {"status": "no_scans"}
    return SCAN_RUNS[0]

class ExploitRequest(BaseModel):
    method: str
    url: str
    auth_header: Optional[str] = "Bearer tok_alice_9981a"
    body: Optional[Dict[str, Any]] = None

@app.post("/api/exploit/execute")
def execute_live_exploit(req: ExploitRequest):
    """Executes a real-time HTTP exploit request and returns latency & response."""
    start = time.time()
    headers = {"Accept": "application/json"}
    if req.auth_header:
        headers["Authorization"] = req.auth_header

    try:
        r = requests.request(req.method, req.url, headers=headers, json=req.body, timeout=4)
        latency = round((time.time() - start) * 1000, 1)
        resp_json = None
        try:
            resp_json = r.json()
        except Exception:
            pass

        resp_str = json.dumps(resp_json) if resp_json else r.text
        is_leaked = any(leak in resp_str for leak in ["Bob Miller", "102", "5002", "$2b$", "ssn", "diagnosis"])

        return {
            "status_code": r.status_code,
            "latency_ms": latency,
            "headers": dict(r.headers),
            "response": resp_json if resp_json is not None else r.text,
            "is_leaked": is_leaked
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Exploit execution failed: {e}")


@app.get("/api/report/html/{scan_id}", response_class=HTMLResponse)
def export_html_report(scan_id: str):
    """Generates a clean, printable technical audit summary."""
    scan = next((s for s in SCAN_RUNS if s["id"] == scan_id), None)
    if not scan and SCAN_RUNS:
        scan = SCAN_RUNS[0]
    if not scan:
        raise HTTPException(status_code=404, detail="Scan not found")

    findings_rows = ""
    for f in scan["findings"]:
        findings_rows += f"""
        <div style="border: 1px solid #334155; border-radius: 8px; padding: 16px; margin-bottom: 20px; background: #0f172a;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                <strong style="color: {'#ef4444' if f['severity'] == 'CRITICAL' else ('#f97316' if f['severity'] == 'HIGH' else '#eab308')};">[{f['severity']}] {f['id']}</strong>
                <span style="font-family: monospace; color: #94a3b8;">{f['method']} {f['endpoint']}</span>
            </div>
            <h4 style="margin: 0 0 6px 0; color: #f1f5f9;">{f['title']}</h4>
            <p style="color: #cbd5e1; font-size: 13px; line-height: 1.5;">{f['description']}</p>
            <div style="margin-top: 10px;">
                <div style="font-size: 12px; font-weight: bold; color: #38bdf8; margin-bottom: 4px;">Reproduction cURL:</div>
                <pre style="background: #1e293b; color: #e2e8f0; padding: 10px; border-radius: 6px; font-size: 12px; overflow-x: auto;">{f.get('reproduction_curl', '')}</pre>
            </div>
            <div style="margin-top: 10px;">
                <div style="font-size: 12px; font-weight: bold; color: #10b981; margin-bottom: 4px;">Recommended Code Patch:</div>
                <pre style="background: #1e293b; color: #a7f3d0; padding: 10px; border-radius: 6px; font-size: 12px; overflow-x: auto;">{f.get('fix_code', '')}</pre>
            </div>
        </div>
        """

    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>API Security Audit Report - {scan['id']}</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #020617; color: #f8fafc; padding: 30px; }}
            .container {{ max-width: 860px; margin: 0 auto; }}
            @media print {{ body {{ background: white; color: black; }} }}
        </style>
    </head>
    <body>
        <div class="container">
            <button onclick="window.print()" style="margin-bottom: 20px; padding: 8px 16px; background: #0284c7; color: white; border: none; border-radius: 4px; cursor: pointer;">Print / Save as PDF</button>
            <h2>API Security Audit Report ({scan['id']})</h2>
            <p><strong>Target:</strong> {scan['target_url']} | <strong>Score:</strong> {scan['summary']['score']}/100 ({scan['summary']['grade']}) | <strong>Date:</strong> {scan['timestamp']}</p>
            <hr style="border-color: #334155; margin: 20px 0;">
            {findings_rows}
        </div>
    </body>
    </html>
    """
    return html

static_path = os.path.join(os.path.dirname(__file__), "..", "static")
app.mount("/static", StaticFiles(directory=static_path), name="static")

@app.get("/", response_class=FileResponse)
def serve_index():
    return FileResponse(os.path.join(static_path, "index.html"))

@app.get("/slides", response_class=FileResponse)
def serve_slides():
    return FileResponse(os.path.join(static_path, "slides.html"))

@app.get("/download-pptx", response_class=FileResponse)
def download_pptx():
    pptx_path = os.path.join(os.path.dirname(__file__), "..", "SentinelAPI_Presentation.pptx")
    if os.path.exists(pptx_path):
        return FileResponse(pptx_path, filename="SentinelAPI_Presentation.pptx", media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation")
    raise HTTPException(status_code=404, detail="File not found")

@app.get("/report", response_class=FileResponse)
def serve_report():
    """Serves the printable hackathon submission report."""
    return FileResponse(os.path.join(static_path, "report.html"))

